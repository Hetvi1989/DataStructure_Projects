# G3B1_DSAJava_Assignment2
Assignment on Data Structures and Algorithms  

contains 2 questions 
 1. program to determine the order of floor construction of a skyscraper - Floor_Construction
 2. Program to covert Binary Search Tree to Skewed tree - BST_to_SkewedTree
